﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Linq;

namespace Ecom
{
    public partial class Cart : System.Web.UI.Page
    {
        protected string CartAmount;
        protected string NetAmount;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                var dbContext = new DataClassesDataContext();

                MainRepeater.DataSource = dbContext.ProductCarts;
                MainRepeater.DataBind();

                var cartAmount = dbContext.ProductCarts.Any() ? dbContext.ProductCarts.Sum(cItem => cItem.Amount) : 0;
                var netAmount = cartAmount > 0 ? cartAmount + 50 : 0;

                CartAmount = cartAmount.ToString("0.00");
                NetAmount = netAmount.ToString("0.00");
            }
        }

        protected void MainRepeater_OnItemCommand(object source, RepeaterCommandEventArgs e)
        {
            try
            {
                if (e.CommandName == "Delete")
                {
                    var dbContext = new DataClassesDataContext();

                    var cartItem = dbContext.ProductCarts.FirstOrDefault(cItem => cItem.ProductId == Convert.ToInt32(e.CommandArgument));
                    if (cartItem != null)
                    {
                        dbContext.ProductCarts.DeleteOnSubmit(cartItem);
                        dbContext.SubmitChanges();
                    }

                    Response.Redirect("Cart.aspx");
                }
            }
            catch
            {
            }
        }
    }
}