﻿using System;
using System.Linq;

namespace Ecom
{
    public partial class Home : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void AddToCart1_Click(object sender, EventArgs e)
        {
            try
            {
                var dbContext = new DataClassesDataContext();

                var cartItem = dbContext.ProductCarts.FirstOrDefault(cItem => cItem.ProductId == 1);
                if (cartItem == null)
                {
                    dbContext.ProductCarts.InsertOnSubmit(new ProductCart
                    {
                        ProductId = 1,
                        ProductName = "Punjabi Suit-Salwar (Machine Work)",
                        Price = 169,
                        Qty = 1,
                        Amount = 169
                    });
                }
                else
                {
                    cartItem.Qty += 1;
                    cartItem.Amount += 169;
                }

                dbContext.SubmitChanges();

                Response.Redirect("Cart.aspx");
            }
            catch
            {
            }
        }

        protected void AddToCart2_Click(object sender, EventArgs e)
        {
            try
            {
                var dbContext = new DataClassesDataContext();

                var cartItem = dbContext.ProductCarts.FirstOrDefault(cItem => cItem.ProductId == 2);
                if (cartItem == null)
                {
                    dbContext.ProductCarts.InsertOnSubmit(new ProductCart
                    {
                        ProductId = 2,
                        ProductName = "Phulkari Suit-Salwar",
                        Price = 259,
                        Qty = 1,
                        Amount = 259
                    });
                }
                else
                {
                    cartItem.Qty += 1;
                    cartItem.Amount += 259;
                }

                dbContext.SubmitChanges();

                Response.Redirect("Cart.aspx");
            }
            catch
            {
            }
        }

        protected void AddToCart3_Click(object sender, EventArgs e)
        {
            try
            {
                var dbContext = new DataClassesDataContext();

                var cartItem = dbContext.ProductCarts.FirstOrDefault(cItem => cItem.ProductId == 3);
                if (cartItem == null)
                {
                    dbContext.ProductCarts.InsertOnSubmit(new ProductCart
                    {
                        ProductId = 3,
                        ProductName = "Punjabi Suit-Sharara",
                        Price = 219,
                        Qty = 1,
                        Amount = 219
                    });
                }
                else
                {
                    cartItem.Qty += 1;
                    cartItem.Amount += 219;
                }

                dbContext.SubmitChanges();

                Response.Redirect("Cart.aspx");
            }
            catch
            {
            }
        }

        protected void AddToCart4_Click(object sender, EventArgs e)
        {
            try
            {
                var dbContext = new DataClassesDataContext();

                var cartItem = dbContext.ProductCarts.FirstOrDefault(cItem => cItem.ProductId == 4);
                if (cartItem == null)
                {
                    dbContext.ProductCarts.InsertOnSubmit(new ProductCart
                    {
                        ProductId = 4,
                        ProductName = "Designer Suit-Salwar (Hand Work)",
                        Price = 449,
                        Qty = 1,
                        Amount = 449
                    });
                }
                else
                {
                    cartItem.Qty += 1;
                    cartItem.Amount += 449;
                }

                dbContext.SubmitChanges();

                Response.Redirect("Cart.aspx");
            }
            catch
            {
            }
        }

        protected void AddToCart5_Click(object sender, EventArgs e)
        {
            try
            {
                var dbContext = new DataClassesDataContext();

                var cartItem = dbContext.ProductCarts.FirstOrDefault(cItem => cItem.ProductId == 5);
                if (cartItem == null)
                {
                    dbContext.ProductCarts.InsertOnSubmit(new ProductCart
                    {
                        ProductId = 5,
                        ProductName = "Wedding Lehnga",
                        Price = 899,
                        Qty = 1,
                        Amount = 899
                    });
                }
                else
                {
                    cartItem.Qty += 1;
                    cartItem.Amount += 899;
                }

                dbContext.SubmitChanges();

                Response.Redirect("Cart.aspx");
            }
            catch
            {
            }
        }

        protected void AddToCart6_Click(object sender, EventArgs e)
        {
            try
            {
                var dbContext = new DataClassesDataContext();

                var cartItem = dbContext.ProductCarts.FirstOrDefault(cItem => cItem.ProductId == 6);
                if (cartItem == null)
                {
                    dbContext.ProductCarts.InsertOnSubmit(new ProductCart
                    {
                        ProductId = 6,
                        ProductName = "Cotton Printed Suit-Salwar",
                        Price = 89,
                        Qty = 1,
                        Amount = 89
                    });
                }
                else
                {
                    cartItem.Qty += 1;
                    cartItem.Amount += 89;
                }

                dbContext.SubmitChanges();

                Response.Redirect("Cart.aspx");
            }
            catch
            {
            }
        }
    }
}