﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Linq;

namespace Ecom.assets
{
    public partial class MainSite : System.Web.UI.MasterPage
    {
        protected string CartTotal;
        protected int CartItemCount;

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                var dbContext = new DataClassesDataContext();

                CartItemCount = dbContext.ProductCarts.Count();
                CartTotal = "AUD " + dbContext.ProductCarts.Sum(product => product.Amount).ToString("0.00");
            }
            catch
            {
                CartItemCount = 0;
                CartTotal = "0.00";
            }
        }
    }
}